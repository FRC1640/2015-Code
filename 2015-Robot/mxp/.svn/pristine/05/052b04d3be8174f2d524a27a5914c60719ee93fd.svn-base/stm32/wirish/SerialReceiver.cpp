/*
 * SerialReceiver.cpp
 *
 *  Created on: Dec 9, 2014
 *      Author: Scott
 */
#include "SerialReceiver.h"



