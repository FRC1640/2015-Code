#define NAVX_MXP_FIRMWARE_VERSION_MAJOR 	1
#define NAVX_MXP_FIRMWARE_VERSION_MINOR		0

#define NAVX_MXP_HARDWARE_VERSION_NUMBER    33 /* Revision 3.3 MXP IO */

// Version Log
//
// 0.1:  Initial Development Version (11/28/2014)
//
// 0.2:  AHRS Feature Development (12/15/2014)
//
// 1.0:  First Release Version (12/28/2014)
//
// Known Issues:  None.
