This library was developed for the nav6 IMU, and was ported to the RoboRio.

In addition to the base nav6 functionality, this library has been updated to add low-level interfaces for accessing the new functionality in the navX MXP, including 9-axis headings and motion detection.

However, work is not yet completed to integrate this low-level functionality access into the robot example program.  stay tuned....