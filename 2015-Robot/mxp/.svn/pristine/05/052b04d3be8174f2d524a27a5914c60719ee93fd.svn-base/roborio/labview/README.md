# navX-MXP-LabVIEW
LabVIEW library for communicating with <a href="http://www.kauailabs.com/store/index.php?route=product/product&product_id=56">Kauailabs' navX MXP Robotics Navigation Sensor</a>.

## Wiki: https://code.google.com/p/navx-mxp/
* Please go here for official updates and questions not about this library.



## Use SPI or I<sup>2</sup>C.
There is no reason to use SERIAL with this wonderful board...you monster...
